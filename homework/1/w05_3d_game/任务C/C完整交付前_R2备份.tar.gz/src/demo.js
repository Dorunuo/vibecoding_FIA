// ============================================================
// demo.js —— 唯一主修改人：C
//
// createDemoController({ level, session }) 返回：
//   reset(), readFrame(playerSnapshot, cameraYaw), isFinished(), stop()
//
// 契约要点（红线）：
//   - Demo 只根据 LEVEL.demoRoute + 真实快照 + 当前 cameraYaw 生成 InputFrame，
//     通过正常移动/互动/计数/开门/胜利逻辑完成，不得瞬移、直接改状态/计数。
//   - readFrame(playerSnapshot, cameraYaw) 的 cameraYaw 是必需参数：
//     moveX/moveY 是相对相机的输入，必须先算目标世界方向再用 cameraYaw 转换。
//
// 当前为【最小占位实现】：不产出移动/互动输入（返回零帧）。等 A + C 在灰盒
// 实测后填写 LEVEL.demoRoute，再由 C 实现路线状态机。A 只保证接口形状正确。
// ============================================================

export function createDemoController({ level, session }) {
  let active = false;

  function reset() {
    active = true;
    // C 实现：重置路线索引、步进计时、超时计时。
  }

  function readFrame(playerSnapshot, cameraYaw) {
    // 占位：返回零帧（保持镜头稳定、不移动、不互动）。
    void playerSnapshot;
    void cameraYaw;
    return {
      moveX: 0,
      moveY: 0,
      lookX: 0,
      lookY: 0,
      jumpPressed: false,
      interactPressed: false,
      sprintHeld: false,
      pausePressed: false,
      confirmPressed: false,
      cancelPressed: false,
    };
  }

  function isFinished() {
    // 占位：路线为空即视为「无可执行步骤」。C 实现真实完成/超时判定。
    return level.demoRoute.length === 0;
  }

  function stop() {
    active = false;
  }

  return { reset, readFrame, isFinished, stop };
}